"""
convex_hull.py
--------------
Core computational geometry module for the Land Boundary Mapping project.

Implements:
  1. Graham Scan algorithm to compute the convex hull of a set of GPS points.
  2. Shoelace formula to compute polygon area (converted to square meters).
  3. Haversine formula to compute real-world distance between two lat/lng points,
     used for perimeter calculation.

Points are represented as dicts: {"lat": float, "lng": float}
Internally, for the pure geometry (orientation/cross-product) steps we treat
(lng, lat) as (x, y) on a flat plane. This is a reasonable approximation for
small land parcels (a few hundred meters to a few km across).
"""

import math
from functools import cmp_to_key


# ---------------------------------------------------------------------------
# Basic geometry helpers
# ---------------------------------------------------------------------------

def _orientation(o, a, b):
    """
    Returns the orientation of the ordered triplet (o, a, b).
      > 0 : counter-clockwise turn
      < 0 : clockwise turn
      = 0 : collinear
    Uses (lng, lat) as (x, y).
    """
    val = (a["lng"] - o["lng"]) * (b["lat"] - o["lat"]) - \
          (a["lat"] - o["lat"]) * (b["lng"] - o["lng"])
    return val


def _dist_sq(o, a):
    """Squared Euclidean distance (in degree-space) between two points."""
    return (a["lng"] - o["lng"]) ** 2 + (a["lat"] - o["lat"]) ** 2


def haversine_distance(p1, p2):
    """
    Great-circle distance in meters between two lat/lng points.
    Used to compute real-world perimeter (not affected by degree-space distortion).
    """
    R = 6371000  # Earth radius in meters
    lat1, lng1 = math.radians(p1["lat"]), math.radians(p1["lng"])
    lat2, lng2 = math.radians(p2["lat"]), math.radians(p2["lng"])

    d_lat = lat2 - lat1
    d_lng = lng2 - lng1

    a = math.sin(d_lat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(d_lng / 2) ** 2
    c = 2 * math.asin(math.sqrt(a))
    return R * c


# ---------------------------------------------------------------------------
# Graham Scan Convex Hull
# ---------------------------------------------------------------------------

def graham_scan(points):
    """
    Computes the convex hull of a list of points using the Graham Scan algorithm.

    Args:
        points: list of dicts, each {"lat": float, "lng": float}

    Returns:
        list of dicts representing the convex hull vertices, in
        counter-clockwise order, starting from the lowest point.

    Time complexity: O(n log n) due to the angular sort.
    """
    # Remove exact duplicate points
    unique_points = []
    seen = set()
    for p in points:
        key = (round(p["lat"], 8), round(p["lng"], 8))
        if key not in seen:
            seen.add(key)
            unique_points.append(p)
    points = unique_points

    n = len(points)
    if n < 3:
        # A hull needs at least 3 non-collinear points.
        return points

    # Step 1: Find the point with the lowest lat (y). Break ties with lowest lng (x).
    pivot = min(points, key=lambda p: (p["lat"], p["lng"]))

    # Step 2: Sort remaining points by polar angle w.r.t. the pivot.
    # If angle is the same (collinear), keep only the farthest point.
    def compare(a, b):
        o = _orientation(pivot, a, b)
        if o == 0:
            # Collinear: closer point comes first, we'll drop it later
            da, db = _dist_sq(pivot, a), _dist_sq(pivot, b)
            return -1 if da < db else (1 if da > db else 0)
        # Counter-clockwise (o > 0) means 'a' comes before 'b' in angle order
        return -1 if o > 0 else 1

    rest = [p for p in points if p is not pivot]
    rest.sort(key=cmp_to_key(compare))

    # Step 3: Build hull using a stack, popping when we make a clockwise turn.
    hull = [pivot]
    for p in rest:
        while len(hull) > 1 and _orientation(hull[-2], hull[-1], p) <= 0:
            hull.pop()
        hull.append(p)

    return hull


# ---------------------------------------------------------------------------
# Area & Perimeter
# ---------------------------------------------------------------------------

def polygon_area_sqm(hull_points):
    """
    Computes the area of a polygon (given as ordered lat/lng vertices)
    in square meters, using an equirectangular projection + Shoelace formula.
    Good approximation for small land parcels.
    """
    if len(hull_points) < 3:
        return 0.0

    R = 6371000  # Earth radius in meters
    lat0 = math.radians(sum(p["lat"] for p in hull_points) / len(hull_points))

    # Project lat/lng to local x/y meters (equirectangular approximation)
    projected = []
    for p in hull_points:
        x = math.radians(p["lng"]) * R * math.cos(lat0)
        y = math.radians(p["lat"]) * R
        projected.append((x, y))

    # Shoelace formula
    area = 0.0
    n = len(projected)
    for i in range(n):
        x1, y1 = projected[i]
        x2, y2 = projected[(i + 1) % n]
        area += (x1 * y2) - (x2 * y1)

    return abs(area) / 2.0


def polygon_perimeter_m(hull_points):
    """Computes the perimeter in meters by summing haversine distances between
    consecutive hull vertices (including closing edge)."""
    if len(hull_points) < 2:
        return 0.0
    n = len(hull_points)
    total = 0.0
    for i in range(n):
        p1 = hull_points[i]
        p2 = hull_points[(i + 1) % n]
        total += haversine_distance(p1, p2)
    return total


# ---------------------------------------------------------------------------
# Parcel overlap detection ("Potential Conflicts")
# ---------------------------------------------------------------------------
# Two land parcels conflict when their boundary polygons physically overlap.
# Since both boundaries are convex hulls, we can compute the EXACT overlap
# region using the Sutherland-Hodgman polygon-clipping algorithm, then measure
# its real area -- this is genuine computational geometry, not a guessed or
# simulated "risk score".

def _project_to_meters(points, ref_lat):
    """Projects a list of {lat, lng} points to local (x, y) meters, using a
    shared reference latitude so two different parcels land in the same
    coordinate frame and can be compared directly."""
    R = 6371000
    lat0 = math.radians(ref_lat)
    return [
        (math.radians(p["lng"]) * R * math.cos(lat0), math.radians(p["lat"]) * R)
        for p in points
    ]


def _shoelace_area(coords):
    area = 0.0
    n = len(coords)
    for i in range(n):
        x1, y1 = coords[i]
        x2, y2 = coords[(i + 1) % n]
        area += (x1 * y2) - (x2 * y1)
    return abs(area) / 2.0


def _clip_polygon(subject, clip):
    """Sutherland-Hodgman clipping: clips `subject` polygon against the convex
    `clip` polygon. Both are lists of (x, y) tuples in counter-clockwise order.
    Returns the clipped (intersection) polygon's vertices."""

    def inside(p, a, b):
        return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= 0

    def intersect(p1, p2, a, b):
        x1, y1 = p1; x2, y2 = p2
        x3, y3 = a; x4, y4 = b
        denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if denom == 0:
            return p2
        t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
        return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))

    output = list(subject)
    cn = len(clip)
    for i in range(cn):
        if not output:
            break
        a, b = clip[i], clip[(i + 1) % cn]
        input_list = output
        output = []
        s = input_list[-1]
        for e in input_list:
            e_in, s_in = inside(e, a, b), inside(s, a, b)
            if e_in:
                if not s_in:
                    output.append(intersect(s, e, a, b))
                output.append(e)
            elif s_in:
                output.append(intersect(s, e, a, b))
            s = e
    return output


def polygons_overlap_area_sqm(hull_a, hull_b):
    """Returns the exact overlap area (in square meters) between two convex
    hull boundaries. Returns 0.0 if they don't intersect at all."""
    if len(hull_a) < 3 or len(hull_b) < 3:
        return 0.0
    all_points = hull_a + hull_b
    ref_lat = sum(p["lat"] for p in all_points) / len(all_points)
    proj_a = _project_to_meters(hull_a, ref_lat)
    proj_b = _project_to_meters(hull_b, ref_lat)
    intersection = _clip_polygon(proj_a, proj_b)
    if len(intersection) < 3:
        return 0.0
    return _shoelace_area(intersection)