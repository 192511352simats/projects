"""
app.py
------
GIS-Based Land Boundary Mapping — ALL-IN-ONE application.

RUN:
    pip install fastapi uvicorn pydantic python-multipart
    python app.py

Then open: http://localhost:8000  (opens automatically)
"""

import csv
import io
import random
import time
from typing import Dict, List

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

# =============================================================================
# 1. CONVEX HULL GEOMETRY
# =============================================================================

import math
from functools import cmp_to_key


# ---------------------------------------------------------------------------
# Basic geometry helpers
# ---------------------------------------------------------------------------

def _orientation(o, a, b):
    """
    Returns the orientation of the ordered triplet (o, a, b).
      > 0 : counter-clockwise turn
      < 0 : clockwise turn
      = 0 : collinear
    Uses (lng, lat) as (x, y).
    """
    val = (a["lng"] - o["lng"]) * (b["lat"] - o["lat"]) - \
          (a["lat"] - o["lat"]) * (b["lng"] - o["lng"])
    return val


def _dist_sq(o, a):
    """Squared Euclidean distance (in degree-space) between two points."""
    return (a["lng"] - o["lng"]) ** 2 + (a["lat"] - o["lat"]) ** 2


def _dedupe(points):
    """Removes exact-duplicate points (rounded to ~1mm precision) so they
    don't distort the sort or the resulting hull shape."""
    seen = set()
    unique_points = []
    for p in points:
        key = (round(p["lat"], 8), round(p["lng"], 8))
        if key not in seen:
            seen.add(key)
            unique_points.append(p)
    return unique_points


def haversine_distance(p1, p2):
    """
    Great-circle distance in meters between two lat/lng points.
    Used to compute real-world perimeter (not affected by degree-space distortion).
    """
    R = 6371000  # Earth radius in meters
    lat1, lng1 = math.radians(p1["lat"]), math.radians(p1["lng"])
    lat2, lng2 = math.radians(p2["lat"]), math.radians(p2["lng"])

    d_lat = lat2 - lat1
    d_lng = lng2 - lng1

    a = math.sin(d_lat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(d_lng / 2) ** 2
    c = 2 * math.asin(math.sqrt(a))
    return R * c


# ---------------------------------------------------------------------------
# Graham Scan Convex Hull
# ---------------------------------------------------------------------------

def graham_scan(points):
    """
    Computes the convex hull of a list of points using the Graham Scan algorithm.

    Args:
        points: list of dicts, each {"lat": float, "lng": float}

    Returns:
        list of dicts representing the convex hull vertices, in
        counter-clockwise order, starting from the lowest point.

    Time complexity: O(n log n) due to the angular sort.
    """
    points = _dedupe(points)
    n = len(points)
    if n < 3:
        # A hull needs at least 3 non-collinear points.
        return points

    # Step 1: Find the point with the lowest lat (y). Break ties with lowest lng (x).
    pivot = min(points, key=lambda p: (p["lat"], p["lng"]))

    # Step 2: Sort remaining points by polar angle w.r.t. the pivot.
    # If angle is the same (collinear), keep only the farthest point.
    def compare(a, b):
        o = _orientation(pivot, a, b)
        if o == 0:
            # Collinear: closer point comes first, we'll drop it later
            da, db = _dist_sq(pivot, a), _dist_sq(pivot, b)
            return -1 if da < db else (1 if da > db else 0)
        # Counter-clockwise (o > 0) means 'a' comes before 'b' in angle order
        return -1 if o > 0 else 1

    rest = [p for p in points if p is not pivot]
    rest.sort(key=cmp_to_key(compare))

    # Step 3: Build hull using a stack, popping when we make a clockwise turn.
    hull = [pivot]
    for p in rest:
        while len(hull) > 1 and _orientation(hull[-2], hull[-1], p) <= 0:
            hull.pop()
        hull.append(p)

    return hull


def jarvis_march(points):
    """
    Computes the convex hull using the Jarvis March ("gift wrapping") algorithm.

    Starting from the leftmost point, it repeatedly finds the point that is
    the most counter-clockwise relative to the current point -- like wrapping
    a piece of string around the outside of the points -- until it wraps back
    around to the start.

    Returns:
        list of dicts representing the convex hull vertices, in
        counter-clockwise order, starting from the leftmost point.

    Time complexity: O(n * h), where h is the number of hull vertices found.
    This beats Graham Scan's O(n log n) when h is small, but degrades toward
    O(n^2) in the worst case (when most points lie on the hull).
    """
    points = _dedupe(points)
    n = len(points)
    if n < 3:
        return points

    # Start from the leftmost point (lowest lng; ties broken by lowest lat).
    start = min(points, key=lambda p: (p["lng"], p["lat"]))

    hull = []
    p = start
    guard = 0
    while True:
        hull.append(p)
        candidate = None
        for r in points:
            if r is p:
                continue
            if candidate is None:
                candidate = r
                continue
            o = _orientation(p, candidate, r)
            if o < 0:
                # r is more counter-clockwise than the current candidate --
                # it "wraps" further around the outside, so it's a better pick.
                candidate = r
            elif o == 0 and _dist_sq(p, r) > _dist_sq(p, candidate):
                # Collinear with the current candidate: keep the farther point.
                candidate = r
        p = candidate
        guard += 1
        if p is start or candidate is None or guard > n + 1:
            break

    return hull


# ---------------------------------------------------------------------------
# Area & Perimeter
# ---------------------------------------------------------------------------

def polygon_area_sqm(hull_points):
    """
    Computes the area of a polygon (given as ordered lat/lng vertices)
    in square meters, using an equirectangular projection + Shoelace formula.
    Good approximation for small land parcels.
    """
    if len(hull_points) < 3:
        return 0.0

    R = 6371000  # Earth radius in meters
    lat0 = math.radians(sum(p["lat"] for p in hull_points) / len(hull_points))

    # Project lat/lng to local x/y meters (equirectangular approximation)
    projected = []
    for p in hull_points:
        x = math.radians(p["lng"]) * R * math.cos(lat0)
        y = math.radians(p["lat"]) * R
        projected.append((x, y))

    # Shoelace formula
    area = 0.0
    n = len(projected)
    for i in range(n):
        x1, y1 = projected[i]
        x2, y2 = projected[(i + 1) % n]
        area += (x1 * y2) - (x2 * y1)

    return abs(area) / 2.0


def polygon_perimeter_m(hull_points):
    """Computes the perimeter in meters by summing haversine distances between
    consecutive hull vertices (including closing edge)."""
    if len(hull_points) < 2:
        return 0.0
    n = len(hull_points)
    total = 0.0
    for i in range(n):
        p1 = hull_points[i]
        p2 = hull_points[(i + 1) % n]
        total += haversine_distance(p1, p2)
    return total


# ---------------------------------------------------------------------------
# Parcel overlap detection ("Potential Conflicts")
# ---------------------------------------------------------------------------
# Two land parcels conflict when their boundary polygons physically overlap.
# Since both boundaries are convex hulls, we can compute the EXACT overlap
# region using the Sutherland-Hodgman polygon-clipping algorithm, then measure
# its real area -- this is genuine computational geometry, not a guessed or
# simulated "risk score".

def _project_to_meters(points, ref_lat):
    """Projects a list of {lat, lng} points to local (x, y) meters, using a
    shared reference latitude so two different parcels land in the same
    coordinate frame and can be compared directly."""
    R = 6371000
    lat0 = math.radians(ref_lat)
    return [
        (math.radians(p["lng"]) * R * math.cos(lat0), math.radians(p["lat"]) * R)
        for p in points
    ]


def _shoelace_area(coords):
    area = 0.0
    n = len(coords)
    for i in range(n):
        x1, y1 = coords[i]
        x2, y2 = coords[(i + 1) % n]
        area += (x1 * y2) - (x2 * y1)
    return abs(area) / 2.0


def _clip_polygon(subject, clip):
    """Sutherland-Hodgman clipping: clips `subject` polygon against the convex
    `clip` polygon. Both are lists of (x, y) tuples in counter-clockwise order.
    Returns the clipped (intersection) polygon's vertices."""

    def inside(p, a, b):
        return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= 0

    def intersect(p1, p2, a, b):
        x1, y1 = p1; x2, y2 = p2
        x3, y3 = a; x4, y4 = b
        denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if denom == 0:
            return p2
        t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
        return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))

    output = list(subject)
    cn = len(clip)
    for i in range(cn):
        if not output:
            break
        a, b = clip[i], clip[(i + 1) % cn]
        input_list = output
        output = []
        s = input_list[-1]
        for e in input_list:
            e_in, s_in = inside(e, a, b), inside(s, a, b)
            if e_in:
                if not s_in:
                    output.append(intersect(s, e, a, b))
                output.append(e)
            elif s_in:
                output.append(intersect(s, e, a, b))
            s = e
    return output


def polygons_overlap_area_sqm(hull_a, hull_b):
    """Returns the exact overlap area (in square meters) between two convex
    hull boundaries. Returns 0.0 if they don't intersect at all."""
    if len(hull_a) < 3 or len(hull_b) < 3:
        return 0.0
    all_points = hull_a + hull_b
    ref_lat = sum(p["lat"] for p in all_points) / len(all_points)
    proj_a = _project_to_meters(hull_a, ref_lat)
    proj_b = _project_to_meters(hull_b, ref_lat)
    intersection = _clip_polygon(proj_a, proj_b)
    if len(intersection) < 3:
        return 0.0
    return _shoelace_area(intersection)


# =============================================================================
# 2. FASTAPI BACKEND
# =============================================================================

app = FastAPI(
    title="Land Boundary Mapping API",
    description="Computes convex-hull land boundaries from GPS survey points.",
    version="1.0.0",
)

# Allow the frontend (served separately) to call this API during development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# In-memory "database": { parcel_id: [ {"lat":..., "lng":..., "label":...}, ... ] }
# ---------------------------------------------------------------------------
parcels: Dict[str, List[dict]] = {}


class Point(BaseModel):
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)
    label: str | None = None


class GenerateRequest(BaseModel):
    center_lat: float = 13.0827
    center_lng: float = 80.2707
    count: int = 25
    spread_m: float = 300  # roughly how far points scatter, in meters


@app.get("/api/status")
def api_status():
    return {"message": "Land Boundary Mapping API is running. See /docs for usage."}


@app.get("/api/parcels")
def list_parcels():
    return {
        "parcels": [
            {"parcel_id": pid, "point_count": len(pts)}
            for pid, pts in parcels.items()
        ]
    }


@app.post("/api/parcels/{parcel_id}/points")
def add_point(parcel_id: str, point: Point):
    parcels.setdefault(parcel_id, []).append(point.dict())
    return {"parcel_id": parcel_id, "total_points": len(parcels[parcel_id])}


@app.get("/api/parcels/{parcel_id}/points")
def get_points(parcel_id: str):
    if parcel_id not in parcels:
        raise HTTPException(status_code=404, detail="Parcel not found")
    return {"parcel_id": parcel_id, "points": parcels[parcel_id]}


@app.delete("/api/parcels/{parcel_id}")
def clear_parcel(parcel_id: str):
    parcels.pop(parcel_id, None)
    return {"parcel_id": parcel_id, "status": "cleared"}


@app.delete("/api/parcels/{parcel_id}/points/{point_index}")
def delete_point(parcel_id: str, point_index: int):
    """Delete a single point from a parcel by its index in the list."""
    if parcel_id not in parcels or not (0 <= point_index < len(parcels[parcel_id])):
        raise HTTPException(status_code=404, detail="Point not found")
    removed = parcels[parcel_id].pop(point_index)
    return {"parcel_id": parcel_id, "removed": removed, "total_points": len(parcels[parcel_id])}


@app.get("/api/parcels/{parcel_id}/hull")
def get_hull(parcel_id: str):
    if parcel_id not in parcels or len(parcels[parcel_id]) < 3:
        raise HTTPException(
            status_code=400,
            detail="Need at least 3 points to compute a convex hull.",
        )

    points = parcels[parcel_id]
    hull = graham_scan(points)
    area = polygon_area_sqm(hull)
    perimeter = polygon_perimeter_m(hull)

    # Return as GeoJSON Polygon (ring must close: first point repeated at end)
    coordinates = [[p["lng"], p["lat"]] for p in hull]
    coordinates.append(coordinates[0])

    return {
        "parcel_id": parcel_id,
        "geojson": {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [coordinates],
            },
            "properties": {
                "area_sqm": round(area, 2),
                "area_acres": round(area / 4046.86, 4),
                "perimeter_m": round(perimeter, 2),
                "vertex_count": len(hull),
                "input_point_count": len(points),
            },
        },
    }


@app.post("/api/parcels/{parcel_id}/generate")
def generate_demo_points(parcel_id: str, req: GenerateRequest):
    """
    Generates synthetic GPS points scattered around a center coordinate.
    Useful for demoing the algorithm without needing real survey data.
    """
    # Rough conversion: 1 degree latitude ~= 111,000 meters
    deg_spread_lat = req.spread_m / 111000
    deg_spread_lng = req.spread_m / (111000 * 0.98)  # approx cos(lat) correction

    points = []
    for _ in range(req.count):
        p = {
            "lat": req.center_lat + random.uniform(-deg_spread_lat, deg_spread_lat),
            "lng": req.center_lng + random.uniform(-deg_spread_lng, deg_spread_lng),
            "label": "synthetic",
        }
        points.append(p)

    parcels[parcel_id] = points
    return {"parcel_id": parcel_id, "generated": len(points)}


@app.post("/api/parcels/{parcel_id}/import")
async def import_points(parcel_id: str, file: UploadFile = File(...)):
    """
    Bulk-import GPS points from a CSV file into a parcel.
    Expected CSV columns: lat, lng, label (label is optional).

    Use this to load either:
      - a REAL dataset produced by data/fetch_real_data.py, or
      - a SYNTHETIC dataset produced by data/generate_synthetic.py

    Example (curl):
        curl -F "file=@real_dataset.csv" \\
             http://localhost:8000/api/parcels/my-parcel/import
    """
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only .csv files are supported.")

    raw = await file.read()
    text = raw.decode("utf-8")
    reader = csv.DictReader(io.StringIO(text))

    imported = []
    for row in reader:
        try:
            lat = float(row["lat"])
            lng = float(row["lng"])
        except (KeyError, ValueError):
            continue  # skip malformed rows
        imported.append({
            "lat": lat,
            "lng": lng,
            "label": row.get("label") or "imported",
        })

    if not imported:
        raise HTTPException(status_code=400, detail="No valid rows found. CSV needs 'lat' and 'lng' columns.")

    parcels.setdefault(parcel_id, []).extend(imported)
    return {"parcel_id": parcel_id, "imported": len(imported), "total_points": len(parcels[parcel_id])}


@app.get("/api/parcels/{parcel_id}/hull-compare")
def compare_algorithms(parcel_id: str):
    """
    Runs BOTH Graham Scan and Jarvis March on the same parcel's points and
    returns real, measured results for each -- vertex count, execution time,
    and whether they agree -- so the two algorithms can be compared directly
    rather than just described.
    """
    if parcel_id not in parcels or len(parcels[parcel_id]) < 3:
        raise HTTPException(status_code=400, detail="Need at least 3 points to compare algorithms.")

    points = parcels[parcel_id]
    n = len(points)

    t0 = time.perf_counter()
    hull_gs = graham_scan(points)
    t1 = time.perf_counter()
    hull_jm = jarvis_march(points)
    t2 = time.perf_counter()

    gs_time = (t1 - t0) * 1000
    jm_time = (t2 - t1) * 1000
    h = len(hull_gs)  # hull vertex count

    gs_set = {(round(p["lat"], 6), round(p["lng"], 6)) for p in hull_gs}
    jm_set = {(round(p["lat"], 6), round(p["lng"], 6)) for p in hull_jm}

    # Honest verdict: report which was actually faster on THIS run, plus the
    # structural reason (h/n ratio) rather than a blanket claim either way.
    hull_ratio = h / n if n else 0
    faster = "graham_scan" if gs_time <= jm_time else "jarvis_march"

    if hull_ratio > 0.5:
        reasoning = (
            f"On this data, {h} of the {n} points ({hull_ratio*100:.0f}%) sit on the boundary "
            f"itself. When most points are hull vertices like this, Jarvis March's cost "
            f"(O(n*h)) approaches O(n^2), while Graham Scan stays a guaranteed O(n log n) "
            f"regardless -- so Graham Scan is the structurally safer choice as data grows, "
            f"which is why this app uses it for the main 'Compute boundary' button."
        )
        recommended = "graham_scan"
    else:
        reasoning = (
            f"On this data, only {h} of the {n} points ({hull_ratio*100:.0f}%) are boundary "
            f"vertices -- a small hull relative to the input. Jarvis March's O(n*h) cost "
            f"benefits from that, so it can be quicker here. But Graham Scan's O(n log n) "
            f"is a guaranteed worst case no matter how the data changes, so it remains the "
            f"safer default as your point count grows -- which is why this app uses it for "
            f"the main 'Compute boundary' button."
        )
        recommended = "graham_scan"  # still the app's structural default, explained above

    return {
        "parcel_id": parcel_id,
        "input_point_count": n,
        "graham_scan": {
            "vertex_count": len(hull_gs),
            "time_ms": round(gs_time, 4),
            "time_complexity": "O(n log n)",
            "vertices": [{"lat": p["lat"], "lng": p["lng"]} for p in hull_gs],
        },
        "jarvis_march": {
            "vertex_count": len(hull_jm),
            "time_ms": round(jm_time, 4),
            "time_complexity": "O(n * h)",
            "vertices": [{"lat": p["lat"], "lng": p["lng"]} for p in hull_jm],
        },
        "faster_on_this_run": faster,
        "recommended_default": recommended,
        "reasoning": reasoning,
        "hulls_match": gs_set == jm_set,
    }


@app.get("/api/dashboard-summary")
def dashboard_summary():
    """Aggregate stats across every parcel, for the Dashboard tab. All numbers
    are derived directly from stored data -- nothing here is simulated."""
    total_parcels = len(parcels)
    total_points = sum(len(pts) for pts in parcels.values())
    label_counts: Dict[str, int] = {}
    parcel_areas = []

    for pid, pts in parcels.items():
        for p in pts:
            lbl = p.get("label") or "unlabeled"
            label_counts[lbl] = label_counts.get(lbl, 0) + 1
        if len(pts) >= 3:
            hull = graham_scan(pts)
            if len(hull) >= 3:
                area = polygon_area_sqm(hull)
                parcel_areas.append({"parcel_id": pid, "area_acres": round(area / 4046.86, 3)})

    total_area_acres = sum(p["area_acres"] for p in parcel_areas)
    return {
        "total_parcels": total_parcels,
        "total_points": total_points,
        "total_area_acres": round(total_area_acres, 3),
        "label_breakdown": label_counts,
        "parcel_areas": parcel_areas,
    }


@app.get("/api/conflicts")
def get_conflicts():
    """
    Detects real overlaps between every pair of parcels' computed boundaries.
    Uses Sutherland-Hodgman polygon clipping to find the EXACT overlap area
    between two convex hulls -- this is genuine computational geometry, not a
    simulated or randomized "risk score".
    """
    parcel_hulls = {}
    for pid, pts in parcels.items():
        if len(pts) >= 3:
            hull = graham_scan(pts)
            if len(hull) >= 3:
                parcel_hulls[pid] = hull

    ids = list(parcel_hulls.keys())
    conflicts = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            a, b = ids[i], ids[j]
            overlap = polygons_overlap_area_sqm(parcel_hulls[a], parcel_hulls[b])
            if overlap > 0:
                area_a = polygon_area_sqm(parcel_hulls[a])
                area_b = polygon_area_sqm(parcel_hulls[b])
                severity_pct = overlap / min(area_a, area_b) * 100
                conflicts.append({
                    "parcel_a": a,
                    "parcel_b": b,
                    "overlap_sqm": round(overlap, 2),
                    "overlap_acres": round(overlap / 4046.86, 4),
                    "severity_pct": round(severity_pct, 2),
                })

    conflicts.sort(key=lambda c: -c["severity_pct"])
    return {"parcels_checked": len(ids), "conflicts": conflicts}




# =============================================================================
# 3. FRONTEND -- served directly by the backend at "/"
# =============================================================================

FRONTEND_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Meridian GIS — Land Boundary Mapping System</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css" />
<style>
  :root {
    --blue: #2F6FED; --blue-dark: #1E4FC4; --blue-tint: #EAF1FE;
    --green: #16A34A; --green-tint: #E7F7ED;
    --amber: #D97706; --amber-tint: #FEF3E2;
    --red: #DC3B3B; --red-tint: #FCE9E9;
    --purple: #6D5DFB;
    --ink: #131A2B; --ink-soft: #66708A;
    --border: #E4E7EE; --card: #FFFFFF; --bg: #F5F7FB;
    --sidebar: #0F1B33; --sidebar-hover: #182946; --sidebar-active: #2F6FED;
    --mono: 'JetBrains Mono', monospace; --disp: 'Sora', sans-serif;
    --shadow: 0 4px 16px rgba(19,26,43,0.07), 0 1px 2px rgba(19,26,43,0.05);
    --shadow-lg: 0 12px 32px rgba(19,26,43,0.14);
  }
  * { box-sizing: border-box; }
  body { margin: 0; font-family: 'Inter', sans-serif; color: var(--ink); background: var(--bg); height: 100vh; overflow: hidden; }
  button, input { font-family: inherit; }
  ::-webkit-scrollbar { width: 8px; height: 8px; }
  ::-webkit-scrollbar-thumb { background: #D3D8E4; border-radius: 4px; }

  /* ===================== App shell ===================== */
  #shell { display: flex; height: 100vh; }

  /* ---- Sidebar ---- */
  #sidebar { width: 232px; background: var(--sidebar); flex-shrink: 0; display: flex; flex-direction: column; }
  #sidebar-brand { display: flex; align-items: center; gap: 10px; padding: 20px 18px 16px; }
  #sidebar-brand .icon { width: 32px; height: 32px; border-radius: 8px; background: linear-gradient(135deg, var(--blue), var(--purple)); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  #sidebar-brand .icon svg { width: 18px; height: 18px; stroke: white; }
  #sidebar-brand .t1 { font-family: var(--disp); font-weight: 700; font-size: 15.5px; color: white; }
  #sidebar-brand .t2 { font-size: 9.5px; color: #8493B8; text-transform: uppercase; letter-spacing: 0.05em; }
  #sidebar-nav { flex: 1; padding: 8px 12px; overflow-y: auto; }
  .side-item {
    display: flex; align-items: center; gap: 11px; padding: 10px 12px; border-radius: 8px;
    color: #AEB9D4; font-size: 13.5px; font-weight: 500; cursor: pointer; margin-bottom: 2px; border: none; background: none; width: 100%; text-align: left;
  }
  .side-item svg { width: 17px; height: 17px; flex-shrink: 0; }
  .side-item:hover { background: var(--sidebar-hover); color: white; }
  .side-item.active { background: var(--sidebar-active); color: white; }
  #sidebar-foot { padding: 14px 18px; font-size: 10.5px; color: #57628A; border-top: 1px solid #1E2C4C; }

  /* ---- Top bar ---- */
  #main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
  #topbar { height: 60px; background: var(--card); border-bottom: 1px solid var(--border); display: flex; align-items: center; padding: 0 22px; gap: 16px; flex-shrink: 0; }
  #global-search { display: flex; align-items: center; gap: 8px; background: var(--bg); border: 1px solid var(--border); border-radius: 8px; padding: 0 12px; height: 38px; width: 340px; }
  #global-search svg { width: 15px; height: 15px; color: var(--ink-soft); flex-shrink: 0; }
  #global-search input { border: none; background: none; outline: none; font-size: 13px; width: 100%; }
  #topbar-spacer { flex: 1; }
  .top-action { display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 500; color: var(--ink-soft); padding: 8px 10px; border-radius: 7px; cursor: pointer; border: none; background: none; position: relative; }
  .top-action:hover { background: var(--bg); color: var(--ink); }
  .top-action svg { width: 17px; height: 17px; }
  #notif-badge { position: absolute; top: 3px; right: 4px; width: 15px; height: 15px; border-radius: 50%; background: var(--red); color: white; font-size: 9px; font-weight: 700; display: flex; align-items: center; justify-content: center; }
  #user-chip { display: flex; align-items: center; gap: 8px; padding: 6px 10px 6px 6px; border-radius: 20px; background: var(--bg); }
  #user-chip .av { width: 26px; height: 26px; border-radius: 50%; background: var(--blue-tint); color: var(--blue-dark); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; }
  #user-chip span { font-size: 12.5px; font-weight: 500; }

  /* ===================== Views ===================== */
  .view { display: none; flex: 1; min-height: 0; }
  .view.active { display: flex; }
  .page-scroll { flex: 1; overflow-y: auto; padding: 26px 32px; }
  .page-head { max-width: 1100px; margin: 0 auto 20px; display: flex; justify-content: space-between; align-items: flex-end; }
  .page-head h1 { font-family: var(--disp); font-size: 21px; margin: 0 0 4px; }
  .page-head p { color: var(--ink-soft); font-size: 13px; margin: 0; }

  /* ---- Dashboard ---- */
  #dash-wrap { max-width: 1100px; margin: 0 auto; }
  .stat-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin-bottom: 18px; }
  .stat-card { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 16px; box-shadow: var(--shadow); display: flex; align-items: center; gap: 12px; }
  .stat-card .icn { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .stat-card .icn svg { width: 20px; height: 20px; }
  .stat-card .val { font-family: var(--disp); font-size: 21px; font-weight: 700; line-height: 1.1; }
  .stat-card .lbl { font-size: 11px; color: var(--ink-soft); margin-top: 2px; }
  .icn.blue { background: var(--blue-tint); color: var(--blue-dark); }
  .icn.green { background: var(--green-tint); color: var(--green); }
  .icn.amber { background: var(--amber-tint); color: var(--amber); }
  .icn.red { background: var(--red-tint); color: var(--red); }

  .dash-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 14px; }
  .panel { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 18px; box-shadow: var(--shadow); }
  .panel h3 { font-family: var(--disp); font-size: 13.5px; margin: 0 0 14px; }
  .donut-row { display: flex; align-items: center; gap: 16px; }
  .legend-item { display: flex; align-items: center; gap: 7px; font-size: 12px; margin-bottom: 6px; }
  .legend-dot { width: 9px; height: 9px; border-radius: 2px; flex-shrink: 0; }
  .legend-item .cnt { margin-left: auto; font-family: var(--mono); color: var(--ink-soft); }
  #conflict-summary-list { font-size: 12px; }
  .conflict-mini { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px dashed var(--border); }
  .conflict-mini:last-child { border-bottom: none; }
  .conflict-mini .sev { font-family: var(--mono); font-weight: 700; color: var(--red); }
  .empty-note { text-align: center; color: var(--ink-soft); font-size: 12px; padding: 20px 10px; }

  /* ---- Explore Map ---- */
  #view-explore { }
  #left-panel { width: 290px; background: var(--card); border-right: 1px solid var(--border); display: flex; flex-direction: column; flex-shrink: 0; overflow: hidden; }
  .lp-section { padding: 14px 16px; border-bottom: 1px solid var(--border); }
  .lp-title { font-family: var(--disp); font-weight: 700; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--ink-soft); margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; }
  .lp-title .n { font-family: var(--mono); font-size: 10px; background: var(--blue-tint); color: var(--blue-dark); padding: 1px 7px; border-radius: 9px; }
  .form-field { margin-bottom: 9px; }
  .form-field label { display: block; font-size: 10px; font-weight: 600; color: var(--ink-soft); text-transform: uppercase; letter-spacing: 0.03em; margin-bottom: 4px; }
  .form-field input { width: 100%; padding: 7px 9px; border: 1px solid var(--border); border-radius: 6px; font-size: 12.5px; font-family: var(--mono); }
  .form-row { display: flex; gap: 8px; }
  .form-row .form-field { flex: 1; }
  .field-error { font-size: 10px; color: var(--red); margin-top: 3px; display: none; }
  .btn { padding: 9px 12px; border-radius: 8px; border: 1px solid var(--border); font-size: 12px; font-weight: 600; cursor: pointer; background: white; color: var(--ink); display: flex; align-items: center; justify-content: center; gap: 6px; }
  .btn:hover { border-color: var(--ink-soft); }
  .btn-primary { background: var(--blue); border-color: var(--blue); color: white; width: 100%; }
  .btn-primary:hover { background: var(--blue-dark); border-color: var(--blue-dark); }
  .btn-text { border: none; background: none; color: var(--red); font-weight: 500; width: 100%; }
  .btn-text:hover { text-decoration: underline; }
  .btn svg { width: 13px; height: 13px; }
  .btn-row { display: flex; gap: 8px; }
  .btn-row .btn { flex: 1; }
  #point-list { flex: 1; overflow-y: auto; padding: 4px 8px; }
  .point-row { display: flex; align-items: center; gap: 8px; padding: 6px 8px; border-radius: 6px; font-size: 11px; }
  .point-row:hover { background: var(--bg); }
  .point-row .pid { width: 20px; font-family: var(--mono); font-weight: 700; color: var(--blue-dark); flex-shrink: 0; }
  .point-row .co { flex: 1; font-family: var(--mono); color: var(--ink-soft); }
  .point-row .del { cursor: pointer; color: var(--ink-soft); border: none; background: none; padding: 2px; }
  .point-row .del:hover { color: var(--red); }
  .point-row .del svg { width: 12px; height: 12px; }
  .layer-toggle-row { display: flex; align-items: center; gap: 8px; padding: 5px 0; font-size: 12px; }
  .layer-toggle-row input { width: auto; margin: 0; }

  #map-wrap { flex: 1; position: relative; }
  #map { width: 100%; height: 100%; }
  #hint { position: absolute; top: 14px; left: 50%; transform: translateX(-50%); background: var(--ink); color: white; padding: 6px 16px; border-radius: 20px; font-size: 11.5px; z-index: 800; }
  #map-controls { position: absolute; bottom: 22px; right: 16px; z-index: 800; display: flex; flex-direction: column; gap: 8px; }
  .ctrl-group { background: var(--card); border-radius: 8px; box-shadow: var(--shadow); overflow: hidden; }
  .ctrl-btn { width: 34px; height: 34px; border: none; background: white; cursor: pointer; display: flex; align-items: center; justify-content: center; border-bottom: 1px solid var(--border); }
  .ctrl-btn:last-child { border-bottom: none; }
  .ctrl-btn:hover { background: var(--bg); }
  .ctrl-btn svg { width: 15px; height: 15px; }
  #coordReadout { position: absolute; bottom: 8px; left: 8px; z-index: 800; font-size: 10px; color: var(--ink-soft); background: rgba(255,255,255,0.88); padding: 3px 9px; border-radius: 4px; font-family: var(--mono); }
  .leaflet-control-zoom { display: none; }
  .leaflet-popup-content .pid2 { font-weight: 700; color: var(--blue-dark); margin-bottom: 3px; }
  .leaflet-popup-content .coord { font-family: var(--mono); font-size: 11px; color: var(--ink-soft); }

  #right-panel { width: 280px; background: var(--card); border-left: 1px solid var(--border); display: flex; flex-direction: column; flex-shrink: 0; }
  .rp-head { padding: 14px 16px 10px; border-bottom: 1px solid var(--border); }
  .rp-head .h1 { font-family: var(--disp); font-weight: 700; font-size: 14px; }
  .rp-head .h2 { font-size: 10.5px; color: var(--ink-soft); margin-top: 3px; line-height: 1.5; }
  .rp-body { padding: 14px 16px; flex: 1; overflow-y: auto; }
  .stat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 14px; }
  .stat { background: var(--bg); border-radius: 8px; padding: 9px 11px; }
  .stat .l { font-size: 9px; color: var(--ink-soft); text-transform: uppercase; letter-spacing: 0.03em; }
  .stat .v { font-family: var(--mono); font-size: 15px; font-weight: 700; color: var(--blue-dark); margin-top: 2px; }
  .stat.green .v { color: var(--green); }
  .rp-sub { font-size: 10px; color: var(--ink-soft); text-transform: uppercase; letter-spacing: 0.04em; margin: 16px 0 6px; }
  .vertex-table { font-family: var(--mono); font-size: 10.5px; border-top: 1px solid var(--border); }
  .vertex-table .r { display: flex; justify-content: space-between; padding: 6px 2px; border-bottom: 1px dashed var(--border); }
  .vertex-table .r .id { color: var(--blue-dark); font-weight: 700; }
  .vertex-table .r .co { color: var(--ink-soft); }
  #status-line { padding: 10px 16px; font-size: 11px; color: var(--ink-soft); border-top: 1px solid var(--border); min-height: 32px; }
  #status-line.err { color: var(--red); }

  /* ---- Parcels ---- */
  #parcels-grid { max-width: 1100px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 14px; }
  .parcel-card { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 16px; box-shadow: var(--shadow); cursor: pointer; transition: box-shadow 0.15s, transform 0.15s; }
  .parcel-card:hover { box-shadow: var(--shadow-lg); transform: translateY(-2px); }
  .parcel-card .pname { font-family: var(--mono); font-weight: 700; font-size: 13px; color: var(--blue-dark); margin-bottom: 8px; word-break: break-all; }
  .parcel-card .pcount { font-size: 12px; color: var(--ink-soft); }
  .parcel-card .pgo { margin-top: 12px; font-size: 12px; font-weight: 600; color: var(--blue); display: flex; align-items: center; gap: 4px; }
  .parcel-card .pgo svg { width: 13px; height: 13px; }

  /* ---- Tables (Conflicts / Reports) ---- */
  .table-wrap { max-width: 1100px; margin: 0 auto; background: var(--card); border: 1px solid var(--border); border-radius: 12px; overflow: hidden; box-shadow: var(--shadow); }
  table.data-table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
  table.data-table th { text-align: left; background: var(--bg); padding: 11px 16px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--ink-soft); border-bottom: 1px solid var(--border); }
  table.data-table td { padding: 11px 16px; border-bottom: 1px solid var(--border); font-family: var(--mono); }
  table.data-table tr:last-child td { border-bottom: none; }
  table.data-table td.pid { font-weight: 700; color: var(--blue-dark); }
  .sev-pill { display: inline-block; padding: 2px 9px; border-radius: 10px; font-size: 10.5px; font-weight: 700; }
  .sev-high { background: var(--red-tint); color: var(--red); }
  .sev-med { background: var(--amber-tint); color: var(--amber); }
  .sev-low { background: var(--green-tint); color: var(--green); }

  .limitation-box { background: var(--amber-tint); border: 1px solid #F1DDA5; border-radius: 10px; padding: 13px 15px; font-size: 12.5px; line-height: 1.6; margin-top: 18px; }
</style>
</head>
<body>

<div id="shell">
  <!-- ===================== SIDEBAR ===================== -->
  <aside id="sidebar">
    <div id="sidebar-brand">
      <div class="icon"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8l6-3 6 3 6-3v13l-6 3-6-3-6 3V8z"/><path d="M9 5v13M15 8v13"/></svg></div>
      <div><div class="t1">Meridian</div><div class="t2">Boundary mapping</div></div>
    </div>
    <nav id="sidebar-nav">
      <button class="side-item active" data-view="dashboard" onclick="switchTab('dashboard')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>
        Dashboard
      </button>
      <button class="side-item" data-view="explore" onclick="switchTab('explore')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s7-6.5 7-12a7 7 0 10-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="9" r="2.4"/></svg>
        Explore Map
      </button>
      <button class="side-item" data-view="parcels" onclick="switchTab('parcels')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>
        Land Parcels
      </button>
      <button class="side-item" data-view="conflicts" onclick="switchTab('conflicts')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 9v4M12 17h.01M10.3 3.9L2.6 18a1.8 1.8 0 001.5 2.7h15.8a1.8 1.8 0 001.5-2.7L13.7 3.9a1.8 1.8 0 00-3.4 0z"/></svg>
        Potential Conflicts
      </button>
      <button class="side-item" data-view="reports" onclick="switchTab('reports')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 6h16M4 12h10M4 18h6"/></svg>
        Reports
      </button>
    </nav>
    <div id="sidebar-foot">© 2026 Meridian GIS</div>
  </aside>

  <!-- ===================== MAIN ===================== -->
  <div id="main">
    <div id="topbar">
      <div id="global-search">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
        <input id="searchInput" placeholder="Search location, parcel ID..." onkeydown="if(event.key==='Enter')searchLocation()" />
      </div>
      <div id="topbar-spacer"></div>
      <button class="top-action" onclick="switchTab('reports')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 00-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0"/></svg>
        Notifications
        <span id="notif-badge" style="display:none;">0</span>
      </button>
      <div id="user-chip"><div class="av">GU</div><span>Guest User</span></div>
    </div>

    <!-- ===================== DASHBOARD VIEW ===================== -->
    <div class="view active" id="view-dashboard">
      <div class="page-scroll">
        <div class="page-head"><div><h1>Dashboard</h1><p>Live overview across every parcel recorded on this backend.</p></div></div>
        <div id="dash-wrap">
          <div class="stat-cards">
            <div class="stat-card"><div class="icn blue"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg></div><div><div class="val" id="dashParcels">–</div><div class="lbl">Parcels tracked</div></div></div>
            <div class="stat-card"><div class="icn green"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s7-6.5 7-12a7 7 0 10-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="9" r="2"/></svg></div><div><div class="val" id="dashPoints">–</div><div class="lbl">GPS points recorded</div></div></div>
            <div class="stat-card"><div class="icn amber"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 3v18h18"/><path d="M7 15l4-6 4 3 4-8"/></svg></div><div><div class="val" id="dashArea">–</div><div class="lbl">Total area (acres)</div></div></div>
            <div class="stat-card"><div class="icn red"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 9v4M12 17h.01M10.3 3.9L2.6 18a1.8 1.8 0 001.5 2.7h15.8a1.8 1.8 0 001.5-2.7L13.7 3.9a1.8 1.8 0 00-3.4 0z"/></svg></div><div><div class="val" id="dashConflicts">–</div><div class="lbl">Conflicts detected</div></div></div>
          </div>
          <div class="dash-grid">
            <div class="panel">
              <h3>Points by source</h3>
              <div class="donut-row"><div id="donutSvgWrap"></div><div id="donutLegend" style="flex:1;"></div></div>
            </div>
            <div class="panel">
              <h3>Area by parcel (acres)</h3>
              <div id="barChartWrap"></div>
            </div>
            <div class="panel">
              <h3>Potential conflicts</h3>
              <div id="conflict-summary-list"><div class="empty-note">No conflicts detected.</div></div>
              <button class="btn" style="width:100%; margin-top:10px;" onclick="switchTab('conflicts')">View all conflicts</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===================== EXPLORE MAP VIEW ===================== -->
    <div class="view" id="view-explore">
      <aside id="left-panel">
        <div class="lp-section">
          <div class="lp-title">Parcel</div>
          <div class="form-field"><label>Parcel ID</label><input id="parcelId" value="parcel-1" onchange="loadPoints()" /></div>
        </div>
        <div class="lp-section">
          <div class="lp-title">Add GPS point manually</div>
          <div class="form-row">
            <div class="form-field"><label>Latitude</label><input id="inLat" placeholder="13.0827" inputmode="decimal" /></div>
            <div class="form-field"><label>Longitude</label><input id="inLng" placeholder="80.2707" inputmode="decimal" /></div>
          </div>
          <div class="field-error" id="coordError">Enter valid latitude (-90 to 90) and longitude (-180 to 180).</div>
          <button class="btn btn-primary" onclick="addManualPoint()" style="margin-top:4px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
            Add point
          </button>
          <div class="btn-row" style="margin-top:8px;">
            <label class="btn" style="cursor:pointer;">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v12M7 8l5-5 5 5M5 21h14"/></svg>
              Import CSV
              <input type="file" id="csvFile" accept=".csv" style="display:none" onchange="importCsv()" />
            </label>
            <button class="btn" onclick="generateDemoPoints()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="6" cy="7" r="1.4"/><circle cx="15" cy="5" r="1.4"/><circle cx="18" cy="13" r="1.4"/></svg>
              Sample set
            </button>
          </div>
        </div>
        <div class="lp-section">
          <div class="lp-title">Map layers</div>
          <label class="layer-toggle-row"><input type="checkbox" id="layerPoints" checked onchange="toggleLayerPoints()" /> GPS points</label>
          <label class="layer-toggle-row"><input type="checkbox" id="layerHull" checked onchange="toggleLayerHull()" /> Boundary polygon</label>
          <label class="layer-toggle-row"><input type="checkbox" id="layerSat" onchange="toggleMapType()" /> Satellite imagery</label>
        </div>
        <div class="lp-section" style="border-bottom:none; flex:1; display:flex; flex-direction:column; min-height:0; padding-bottom:0;">
          <div class="lp-title">GPS points <span class="n" id="pointCount">0</span></div>
          <div id="point-list"><div class="empty-note" id="emptyNote">No points yet.</div></div>
        </div>
        <div class="lp-section"><button class="btn btn-text" onclick="clearParcel()">Clear all points in this parcel</button></div>
      </aside>

      <div id="map-wrap">
        <div id="hint">Click the map to add a point, or type coordinates on the left</div>
        <div id="map"></div>
        <div id="coordReadout">–, –</div>
        <div id="map-controls">
          <div class="ctrl-group">
            <button class="ctrl-btn" onclick="map.zoomIn()" title="Zoom in"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg></button>
            <button class="ctrl-btn" onclick="map.zoomOut()" title="Zoom out"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/></svg></button>
          </div>
          <div class="ctrl-group">
            <button class="ctrl-btn" onclick="fitToPoints()" title="Fit to points"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M8 3H5a2 2 0 00-2 2v3M16 3h3a2 2 0 012 2v3M8 21H5a2 2 0 01-2-2v-3M16 21h3a2 2 0 002-2v-3"/></svg></button>
            <button class="ctrl-btn" onclick="locateMe()" title="Locate me"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></svg></button>
          </div>
        </div>
      </div>

      <aside id="right-panel">
        <div class="rp-head"><div class="h1">Convex hull boundary</div><div class="h2">Runs Graham Scan on all recorded points.</div></div>
        <div class="rp-body">
          <button class="btn btn-primary" onclick="computeHull()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 12l5 5L20 7"/></svg>
            Compute boundary
          </button>
          <div id="resultsBlock" style="display:none;">
            <div class="stat-grid">
              <div class="stat green"><div class="l">Area (acres)</div><div class="v" id="statAcres">–</div></div>
              <div class="stat green"><div class="l">Area (ha)</div><div class="v" id="statHectares">–</div></div>
              <div class="stat"><div class="l">Perimeter (m)</div><div class="v" id="statPerimeter">–</div></div>
              <div class="stat"><div class="l">Boundary pts</div><div class="v" id="statVertices">–</div></div>
            </div>
            <div class="rp-sub">Boundary vertices (lat, lng)</div>
            <div class="vertex-table" id="vertexTable"></div>
          </div>
          <div class="empty-note" id="rpEmpty">Add at least 3 points, then compute the boundary.</div>
        </div>
        <div id="status-line"></div>
      </aside>
    </div>

    <!-- ===================== LAND PARCELS VIEW ===================== -->
    <div class="view" id="view-parcels">
      <div class="page-scroll">
        <div class="page-head"><div><h1>Land parcels</h1><p>Every parcel recorded on this backend. Click a card to open it in Explore Map.</p></div></div>
        <div id="parcels-grid"></div>
        <div id="parcels-empty" class="empty-note" style="display:none;">No parcels yet.</div>
      </div>
    </div>

    <!-- ===================== POTENTIAL CONFLICTS VIEW ===================== -->
    <div class="view" id="view-conflicts">
      <div class="page-scroll">
        <div class="page-head"><div><h1>Potential conflicts</h1><p>Real polygon-overlap detection between every pair of parcel boundaries (Sutherland-Hodgman clipping) — not a simulated score.</p></div></div>
        <div class="table-wrap" id="conflicts-table-wrap" style="display:none;">
          <table class="data-table">
            <thead><tr><th>Parcel A</th><th>Parcel B</th><th>Overlap (acres)</th><th>Overlap (sq. m)</th><th>Severity</th></tr></thead>
            <tbody id="conflicts-tbody"></tbody>
          </table>
        </div>
        <div id="conflicts-empty" class="empty-note">No overlaps detected between any parcels yet.</div>
      </div>
    </div>

    <!-- ===================== REPORTS VIEW ===================== -->
    <div class="view" id="view-reports">
      <div class="page-scroll">
        <div class="page-head"><div><h1>Boundary reports</h1><p>Every boundary computed this session, with area and perimeter.</p></div></div>
        <div class="table-wrap" id="reports-table-wrap" style="display:none;">
          <table class="data-table">
            <thead><tr><th>Parcel</th><th>Input pts</th><th>Boundary pts</th><th>Area (acres)</th><th>Area (ha)</th><th>Perimeter (m)</th></tr></thead>
            <tbody id="reports-tbody"></tbody>
          </table>
        </div>
        <div id="reports-empty" class="empty-note">No boundaries computed yet this session.</div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
  const CHART_COLORS = ['#2F6FED', '#16A34A', '#D97706', '#6D5DFB', '#DC3B3B', '#0EA5A0'];

  function switchTab(name) {
    document.querySelectorAll('.side-item').forEach(t => t.classList.toggle('active', t.dataset.view === name));
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + name));
    if (name === 'dashboard') loadDashboard();
    if (name === 'parcels') loadParcelsView();
    if (name === 'conflicts') loadConflictsView();
    if (name === 'reports') renderReportsView();
    if (name === 'explore') setTimeout(() => map.invalidateSize(), 50);
  }

  function apiBase() { return ''; } // same origin -- served by this app's own backend
  function parcelId() { return document.getElementById('parcelId').value.trim(); }
  function setStatus(msg, isError) {
    const el = document.getElementById('status-line');
    el.textContent = msg;
    el.className = isError ? 'err' : '';
  }

  // ============================================================
  // Map (Explore Map tab)
  // ============================================================
  const map = L.map('map', { zoomControl: false }).setView([13.0827, 80.2707], 14);
  const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors', maxZoom: 19 }).addTo(map);
  const satLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { attribution: 'Tiles &copy; Esri', maxZoom: 19 });
  let usingSatellite = false;
  let pointMarkers = [], currentPoints = [], hullLayer = null;
  let sessionReports = [];
  let sessionEventCount = 0;

  map.on('mousemove', e => { document.getElementById('coordReadout').textContent = `${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`; });

  function bumpNotifications() {
    sessionEventCount++;
    const badge = document.getElementById('notif-badge');
    badge.style.display = 'flex';
    badge.textContent = sessionEventCount > 9 ? '9+' : sessionEventCount;
  }

  function renderPointList() {
    const list = document.getElementById('point-list');
    document.getElementById('pointCount').textContent = currentPoints.length;
    if (!currentPoints.length) { list.innerHTML = '<div class="empty-note" id="emptyNote">No points yet.</div>'; return; }
    list.innerHTML = currentPoints.map((p, i) => `
      <div class="point-row"><span class="pid">P${i+1}</span><span class="co">${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}</span>
      <button class="del" onclick="deletePoint(${i})"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div>
    `).join('');
  }

  function drawMarkers() {
    pointMarkers.forEach(m => map.removeLayer(m));
    pointMarkers = [];
    const show = document.getElementById('layerPoints').checked;
    currentPoints.forEach((p, i) => {
      const marker = L.circleMarker([p.lat, p.lng], { radius: 7, color: '#1E4FC4', weight: 2, fillColor: '#2F6FED', fillOpacity: 0.9 });
      marker.bindPopup(`<div class="pid2">Point ID: P${String(i+1).padStart(3,'0')}</div><div class="coord">Latitude: ${p.lat.toFixed(5)}</div><div class="coord">Longitude: ${p.lng.toFixed(5)}</div>`);
      if (show) marker.addTo(map);
      pointMarkers.push(marker);
    });
  }
  function toggleLayerPoints() { drawMarkers(); }
  function toggleLayerHull() {
    if (!hullLayer) return;
    if (document.getElementById('layerHull').checked) hullLayer.addTo(map); else map.removeLayer(hullLayer);
  }

  async function loadPoints() {
    try {
      const res = await fetch(`${apiBase()}/api/parcels/${parcelId()}/points`);
      if (!res.ok) { currentPoints = []; renderPointList(); drawMarkers(); return; }
      const data = await res.json();
      currentPoints = data.points;
      renderPointList(); drawMarkers();
    } catch { currentPoints = []; renderPointList(); drawMarkers(); }
  }

  function validateCoords(lat, lng) { return !isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180; }

  async function addManualPoint() {
    const latInput = document.getElementById('inLat'), lngInput = document.getElementById('inLng'), err = document.getElementById('coordError');
    const lat = parseFloat(latInput.value), lng = parseFloat(lngInput.value);
    if (!validateCoords(lat, lng)) { err.style.display = 'block'; return; }
    err.style.display = 'none';
    try {
      const res = await fetch(`${apiBase()}/api/parcels/${parcelId()}/points`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lat, lng, label: 'manual' }) });
      if (!res.ok) throw new Error(await res.text());
      setStatus(`Added point at ${lat.toFixed(5)}, ${lng.toFixed(5)}`);
      latInput.value = ''; lngInput.value = '';
      bumpNotifications();
      await loadPoints();
      map.panTo([lat, lng]);
    } catch (e) { setStatus('Error adding point: ' + e.message, true); }
  }

  async function deletePoint(index) {
    try {
      const res = await fetch(`${apiBase()}/api/parcels/${parcelId()}/points/${index}`, { method: 'DELETE' });
      if (!res.ok) throw new Error(await res.text());
      setStatus('Point removed.');
      await loadPoints();
    } catch (e) { setStatus('Error removing point: ' + e.message, true); }
  }

  map.on('click', async (e) => {
    const { lat, lng } = e.latlng;
    try {
      const res = await fetch(`${apiBase()}/api/parcels/${parcelId()}/points`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lat, lng, label: 'manual' }) });
      if (!res.ok) throw new Error(await res.text());
      setStatus(`Point recorded at ${lat.toFixed(5)}, ${lng.toFixed(5)}`);
      bumpNotifications();
      await loadPoints();
    } catch (err) { setStatus('Error recording point: ' + err.message, true); }
  });

  async function generateDemoPoints() {
    const center = map.getCenter();
    try {
      const res = await fetch(`${apiBase()}/api/parcels/${parcelId()}/generate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ center_lat: center.lat, center_lng: center.lng, count: 25, spread_m: 300 }) });
      const data = await res.json();
      setStatus(`Generated ${data.generated} sample GPS points`);
      bumpNotifications();
      await loadPoints();
    } catch (err) { setStatus('Error generating points: ' + err.message, true); }
  }

  async function importCsv() {
    const fileInput = document.getElementById('csvFile');
    if (!fileInput.files.length) return;
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);
    try {
      const res = await fetch(`${apiBase()}/api/parcels/${parcelId()}/import`, { method: 'POST', body: formData });
      if (!res.ok) { const t = await res.json(); throw new Error(t.detail || res.statusText); }
      const data = await res.json();
      setStatus(`Imported ${data.imported} points (total ${data.total_points})`);
      bumpNotifications();
      await loadPoints();
    } catch (err) { setStatus('Error importing CSV: ' + err.message, true); }
  }

  async function computeHull() {
    try {
      const res = await fetch(`${apiBase()}/api/parcels/${parcelId()}/hull`);
      if (!res.ok) { const t = await res.json(); throw new Error(t.detail || res.statusText); }
      const data = await res.json();
      const geo = data.geojson;

      if (hullLayer) map.removeLayer(hullLayer);
      hullLayer = L.geoJSON(geo, { style: { color: '#1E4FC4', weight: 2, fillColor: '#6D5DFB', fillOpacity: 0.28 } });
      if (document.getElementById('layerHull').checked) hullLayer.addTo(map);
      map.fitBounds(hullLayer.getBounds(), { padding: [40, 40] });

      document.getElementById('resultsBlock').style.display = 'block';
      document.getElementById('rpEmpty').style.display = 'none';
      document.getElementById('statVertices').textContent = geo.properties.vertex_count;
      document.getElementById('statAcres').textContent = geo.properties.area_acres;
      document.getElementById('statHectares').textContent = (geo.properties.area_sqm / 10000).toFixed(3);
      document.getElementById('statPerimeter').textContent = Math.round(geo.properties.perimeter_m).toLocaleString();

      const coords = geo.geometry.coordinates[0].slice(0, -1);
      document.getElementById('vertexTable').innerHTML = coords.map((c, i) => `<div class="r"><span class="id">V${i+1}</span><span class="co">${c[1].toFixed(5)}, ${c[0].toFixed(5)}</span></div>`).join('');

      sessionReports = sessionReports.filter(r => r.parcelId !== parcelId());
      sessionReports.unshift({ parcelId: parcelId(), input: geo.properties.input_point_count, vertices: geo.properties.vertex_count, acres: geo.properties.area_acres, hectares: (geo.properties.area_sqm / 10000).toFixed(3), perimeter: Math.round(geo.properties.perimeter_m) });

      setStatus('Boundary computed and logged to Reports.');
      bumpNotifications();
    } catch (err) { setStatus('Error computing boundary: ' + err.message, true); }
  }

  function buildCompareHTML(data) {
    const gs = data.graham_scan, jm = data.jarvis_march;
    const rows = `
      <div style="display:flex; justify-content:space-between; padding:4px 0; border-bottom:1px dashed var(--border);"><span></span><span style="font-weight:700; color:var(--blue-dark);">Graham Scan ✓</span><span style="font-weight:600; color:var(--purple);">Jarvis March</span></div>
      <div style="display:flex; justify-content:space-between; padding:4px 0; border-bottom:1px dashed var(--border);"><span>Boundary vertices</span><span>${gs.vertex_count}</span><span>${jm.vertex_count}</span></div>
      <div style="display:flex; justify-content:space-between; padding:4px 0; border-bottom:1px dashed var(--border);"><span>Time taken (this run)</span><span>${gs.time_ms} ms</span><span>${jm.time_ms} ms</span></div>
      <div style="display:flex; justify-content:space-between; padding:4px 0;"><span>Worst-case complexity</span><span style="font-weight:600; color:var(--blue-dark);">${gs.time_complexity}</span><span>${jm.time_complexity}</span></div>
    `;
    let verdict = '';
    if (data.hulls_match) {
      verdict += `<div style="color:var(--green);">✓ Both algorithms agree — identical ${gs.vertex_count}-point boundary, as expected mathematically.</div>`;
    } else {
      verdict += `<div style="color:var(--red);">✗ Hulls differ — unexpected, check for duplicate/collinear points.</div>`;
    }
    verdict += `<div style="margin-top:8px; padding:9px 10px; background:var(--blue-tint); border-radius:6px; color:var(--blue-dark); font-weight:600;">
      Recommended: <b>Graham Scan</b>
    </div>
    <div style="margin-top:6px; color:var(--ink-soft); font-weight:400; line-height:1.5;">${data.reasoning}</div>`;
    return { rows, verdict };
  }

  async function clearParcel() {
    await fetch(`${apiBase()}/api/parcels/${parcelId()}`, { method: 'DELETE' });
    if (hullLayer) { map.removeLayer(hullLayer); hullLayer = null; }
    document.getElementById('resultsBlock').style.display = 'none';
    document.getElementById('rpEmpty').style.display = 'block';
    await loadPoints();
    setStatus('Parcel cleared.');
  }

  function fitToPoints() {
    if (!pointMarkers.length) { setStatus('No points to fit to.', true); return; }
    map.fitBounds(L.featureGroup(pointMarkers).getBounds(), { padding: [40, 40] });
  }
  function locateMe() {
    if (!navigator.geolocation) { setStatus('Geolocation not supported.', true); return; }
    navigator.geolocation.getCurrentPosition(pos => map.setView([pos.coords.latitude, pos.coords.longitude], 15), () => setStatus('Could not get your location.', true));
  }
  function toggleMapType() {
    usingSatellite = document.getElementById('layerSat').checked;
    if (usingSatellite) { map.removeLayer(osmLayer); satLayer.addTo(map); } else { map.removeLayer(satLayer); osmLayer.addTo(map); }
  }
  async function searchLocation() {
    const q = document.getElementById('searchInput').value.trim();
    if (!q) return;
    switchTab('explore');
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q)}&limit=1`);
      const results = await res.json();
      if (results.length) { map.setView([parseFloat(results[0].lat), parseFloat(results[0].lon)], 14); setStatus(`Moved to: ${results[0].display_name}`); }
      else setStatus('Location not found.', true);
    } catch (err) { setStatus('Search failed: ' + err.message, true); }
  }

  // ============================================================
  // Dashboard tab
  // ============================================================
  function renderDonut(wrapId, legendId, data) {
    const wrap = document.getElementById(wrapId), legend = document.getElementById(legendId);
    const total = data.reduce((s, d) => s + d.count, 0);
    if (!total) { wrap.innerHTML = ''; legend.innerHTML = '<div class="empty-note">No points recorded yet.</div>'; return; }
    const r = 46, circ = 2 * Math.PI * r;
    let offset = 0;
    let circles = '';
    data.forEach((d, i) => {
      const frac = d.count / total;
      const dash = frac * circ;
      circles += `<circle cx="60" cy="60" r="${r}" fill="none" stroke="${CHART_COLORS[i % CHART_COLORS.length]}" stroke-width="16" stroke-dasharray="${dash} ${circ - dash}" stroke-dashoffset="${-offset}" transform="rotate(-90 60 60)"/>`;
      offset += dash;
    });
    wrap.innerHTML = `<svg width="120" height="120" viewBox="0 0 120 120">${circles}<text x="60" y="64" text-anchor="middle" font-family="JetBrains Mono" font-size="18" font-weight="700" fill="#131A2B">${total}</text></svg>`;
    legend.innerHTML = data.map((d, i) => `<div class="legend-item"><span class="legend-dot" style="background:${CHART_COLORS[i % CHART_COLORS.length]}"></span>${d.label}<span class="cnt">${d.count}</span></div>`).join('');
  }

  function renderBarChart(wrapId, data) {
    const wrap = document.getElementById(wrapId);
    if (!data.length) { wrap.innerHTML = '<div class="empty-note">No parcels with a computed boundary yet.</div>'; return; }
    const max = Math.max(...data.map(d => d.value), 0.001);
    wrap.innerHTML = data.slice(0, 6).map(d => `
      <div style="margin-bottom:9px;">
        <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:3px;"><span style="font-family:monospace; color:#131A2B;">${d.label}</span><span style="color:#66708A;">${d.value.toFixed(2)} ac</span></div>
        <div style="background:#F5F7FB; border-radius:4px; height:8px; overflow:hidden;"><div style="background:#2F6FED; height:100%; width:${(d.value/max*100).toFixed(1)}%; border-radius:4px;"></div></div>
      </div>
    `).join('');
  }

  function severityClass(pct) { return pct >= 40 ? 'sev-high' : pct >= 15 ? 'sev-med' : 'sev-low'; }
  function severityLabel(pct) { return pct >= 40 ? 'High' : pct >= 15 ? 'Medium' : 'Low'; }

  async function loadDashboard() {
    try {
      const res = await fetch(`${apiBase()}/api/dashboard-summary`);
      const data = await res.json();
      document.getElementById('dashParcels').textContent = data.total_parcels;
      document.getElementById('dashPoints').textContent = data.total_points;
      document.getElementById('dashArea').textContent = data.total_area_acres.toLocaleString();

      const donutData = Object.entries(data.label_breakdown).map(([label, count]) => ({ label, count }));
      renderDonut('donutSvgWrap', 'donutLegend', donutData);

      const barData = data.parcel_areas.map(p => ({ label: p.parcel_id, value: p.area_acres })).sort((a,b) => b.value - a.value);
      renderBarChart('barChartWrap', barData);
    } catch (e) { setStatus && setStatus('Could not reach backend for dashboard.', true); }

    try {
      const cres = await fetch(`${apiBase()}/api/conflicts`);
      const cdata = await cres.json();
      document.getElementById('dashConflicts').textContent = cdata.conflicts.length;
      const list = document.getElementById('conflict-summary-list');
      if (!cdata.conflicts.length) { list.innerHTML = '<div class="empty-note">No conflicts detected.</div>'; }
      else {
        list.innerHTML = cdata.conflicts.slice(0, 4).map(c => `<div class="conflict-mini"><span>${c.parcel_a} ↔ ${c.parcel_b}</span><span class="sev">${c.severity_pct}%</span></div>`).join('');
      }
    } catch {}
  }

  // ============================================================
  // Parcels tab
  // ============================================================
  async function loadParcelsView() {
    const grid = document.getElementById('parcels-grid');
    const empty = document.getElementById('parcels-empty');
    try {
      const res = await fetch(`${apiBase()}/api/parcels`);
      const data = await res.json();
      if (!data.parcels.length) { grid.innerHTML = ''; empty.style.display = 'block'; return; }
      empty.style.display = 'none';
      grid.innerHTML = data.parcels.map(p => `
        <div class="parcel-card" id="pcard-${p.parcel_id}">
          <div onclick="openParcel('${p.parcel_id}')" style="cursor:pointer;">
            <div class="pname">${p.parcel_id}</div>
            <div class="pcount">${p.point_count} GPS point${p.point_count === 1 ? '' : 's'}</div>
            <div class="pgo">Open in Explore Map <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div>
          </div>
          <button class="btn" style="width:100%; margin-top:10px; font-size:11px; padding:7px 10px;" onclick="event.stopPropagation(); compareOnCard('${p.parcel_id}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M8 3v18M16 3v18M3 8h5M16 8h5M3 16h5M16 16h5"/></svg>
            Compare algorithms
          </button>
          <div id="pcompare-${p.parcel_id}" style="display:none; margin-top:10px; background:var(--bg); border-radius:8px; padding:10px 11px; font-size:11px;"></div>
        </div>`).join('');
    } catch { empty.style.display = 'block'; empty.textContent = 'Could not reach the backend.'; grid.innerHTML = ''; }
  }
  function openParcel(id) { document.getElementById('parcelId').value = id; switchTab('explore'); loadPoints(); }

  async function compareOnCard(id) {
    const box = document.getElementById(`pcompare-${id}`);
    box.style.display = 'block';
    box.innerHTML = 'Comparing…';
    try {
      const res = await fetch(`${apiBase()}/api/parcels/${id}/hull-compare`);
      if (!res.ok) { const t = await res.json(); throw new Error(t.detail || res.statusText); }
      const data = await res.json();
      const { rows, verdict } = buildCompareHTML(data);
      box.innerHTML = `<div style="font-family:var(--disp); font-weight:700; margin-bottom:6px;">Algorithm comparison</div>${rows}<div style="margin-top:6px;">${verdict}</div>`;
    } catch (e) {
      box.innerHTML = `<span style="color:var(--red);">${e.message}</span>`;
    }
  }

  // ============================================================
  // Conflicts tab
  // ============================================================
  async function loadConflictsView() {
    const wrap = document.getElementById('conflicts-table-wrap');
    const empty = document.getElementById('conflicts-empty');
    const tbody = document.getElementById('conflicts-tbody');
    try {
      const res = await fetch(`${apiBase()}/api/conflicts`);
      const data = await res.json();
      if (!data.conflicts.length) { wrap.style.display = 'none'; empty.style.display = 'block'; return; }
      empty.style.display = 'none'; wrap.style.display = 'block';
      tbody.innerHTML = data.conflicts.map(c => `
        <tr>
          <td class="pid">${c.parcel_a}</td>
          <td class="pid">${c.parcel_b}</td>
          <td>${c.overlap_acres}</td>
          <td>${c.overlap_sqm.toLocaleString()}</td>
          <td><span class="sev-pill ${severityClass(c.severity_pct)}">${severityLabel(c.severity_pct)} · ${c.severity_pct}%</span></td>
        </tr>`).join('');
    } catch { empty.style.display = 'block'; empty.textContent = 'Could not reach the backend.'; wrap.style.display = 'none'; }
  }

  // ============================================================
  // Reports tab
  // ============================================================
  function renderReportsView() {
    const wrap = document.getElementById('reports-table-wrap');
    const empty = document.getElementById('reports-empty');
    const tbody = document.getElementById('reports-tbody');
    if (!sessionReports.length) { wrap.style.display = 'none'; empty.style.display = 'block'; return; }
    empty.style.display = 'none'; wrap.style.display = 'block';
    tbody.innerHTML = sessionReports.map(r => `<tr><td class="pid">${r.parcelId}</td><td>${r.input}</td><td>${r.vertices}</td><td>${r.acres}</td><td>${r.hectares}</td><td>${r.perimeter.toLocaleString()}</td></tr>`).join('');
  }

  loadPoints();
  loadDashboard();
</script>
</body>
</html>
"""


@app.get("/", response_class=HTMLResponse)
def serve_frontend():
    return FRONTEND_HTML


if __name__ == "__main__":
    import uvicorn
    import webbrowser
    import threading

    def open_browser():
        webbrowser.open("http://localhost:8000")

    threading.Timer(1.5, open_browser).start()
    print("Starting Meridian GIS Land Boundary Mapping app...")
    print("Open http://localhost:8000 in your browser (it should open automatically).")
    uvicorn.run(app, host="0.0.0.0", port=8000)