"""
generate_synthetic.py
----------------------
Generates a SYNTHETIC dataset of GPS survey points scattered around a center
coordinate, and saves it as a CSV -- useful when you don't have (or can't
reach) real data, or want a controlled dataset for testing edge cases.

This mirrors the /generate endpoint in main.py, but as a standalone script
so you can produce a CSV file directly for your report/dataset folder.

Usage:
    python generate_synthetic.py --lat 13.0827 --lng 80.2707 --count 30 --spread 300 --out synthetic_dataset.csv

    --lat, --lng   Center point (default: Chennai, India)
    --count        Number of points to generate (default: 25)
    --spread       Roughly how far points scatter from center, in meters (default: 300)
    --shape        "random" (uniform scatter) or "ring" (points near a rough
                    boundary circle, more realistic for a hull demo) (default: ring)
    --out          Output CSV filename (default: synthetic_dataset.csv)
    --seed         Random seed for reproducibility (optional)
"""

import argparse
import csv
import math
import random


def generate_random(center_lat, center_lng, count, spread_m):
    """Uniformly scattered points -- good for testing interior-point rejection."""
    deg_spread_lat = spread_m / 111000
    deg_spread_lng = spread_m / (111000 * math.cos(math.radians(center_lat)))

    points = []
    for _ in range(count):
        points.append({
            "lat": center_lat + random.uniform(-deg_spread_lat, deg_spread_lat),
            "lng": center_lng + random.uniform(-deg_spread_lng, deg_spread_lng),
            "label": "synthetic_random",
        })
    return points


def generate_ring(center_lat, center_lng, count, spread_m):
    """
    Points scattered near a rough circular boundary (with some jitter),
    which more realistically resembles a land parcel's edge survey points
    and produces a cleaner, more convex-looking hull.
    """
    deg_radius_lat = spread_m / 111000
    deg_radius_lng = spread_m / (111000 * math.cos(math.radians(center_lat)))

    points = []
    for i in range(count):
        angle = (2 * math.pi * i) / count
        jitter = random.uniform(0.85, 1.0)  # slight inward/outward jitter
        lat = center_lat + math.sin(angle) * deg_radius_lat * jitter
        lng = center_lng + math.cos(angle) * deg_radius_lng * jitter
        points.append({"lat": lat, "lng": lng, "label": "synthetic_ring"})
    return points


def save_csv(points, out_path):
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["lat", "lng", "label"])
        writer.writeheader()
        writer.writerows(points)
    print(f"Saved {len(points)} synthetic points to {out_path}")


def main():
    parser = argparse.ArgumentParser(description="Generate a synthetic GPS point dataset.")
    parser.add_argument("--lat", type=float, default=13.0827, help="Center latitude")
    parser.add_argument("--lng", type=float, default=80.2707, help="Center longitude")
    parser.add_argument("--count", type=int, default=25, help="Number of points")
    parser.add_argument("--spread", type=float, default=300, help="Spread radius in meters")
    parser.add_argument("--shape", choices=["random", "ring"], default="ring")
    parser.add_argument("--out", type=str, default="synthetic_dataset.csv")
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()

    if args.seed is not None:
        random.seed(args.seed)

    if args.shape == "ring":
        points = generate_ring(args.lat, args.lng, args.count, args.spread)
    else:
        points = generate_random(args.lat, args.lng, args.count, args.spread)

    save_csv(points, args.out)
    print("Tip: use the /api/parcels/{id}/import endpoint (see main.py) to load this CSV into the app.")


if __name__ == "__main__":
    main()
