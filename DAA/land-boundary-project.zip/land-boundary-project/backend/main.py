"""
main.py
-------
FastAPI backend for the GIS-Based Land Boundary Mapping project.

Endpoints:
  POST   /api/parcels/{parcel_id}/points        Add a survey point to a parcel
  GET    /api/parcels/{parcel_id}/points        Get all raw points for a parcel
  GET    /api/parcels/{parcel_id}/hull          Compute & return the convex hull
  DELETE /api/parcels/{parcel_id}                Clear all points for a parcel
  GET    /api/parcels                            List all parcel IDs
  POST   /api/parcels/{parcel_id}/generate       Generate synthetic demo points

Storage: in-memory dict for simplicity (swap for PostgreSQL/PostGIS in production
-- see README for how to extend this with SQLAlchemy models).

Run with:
    uvicorn main:app --reload --port 8000
"""

import csv
import io
import random
from typing import Dict, List

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from convex_hull import graham_scan, polygon_area_sqm, polygon_perimeter_m, polygons_overlap_area_sqm

app = FastAPI(
    title="Land Boundary Mapping API",
    description="Computes convex-hull land boundaries from GPS survey points.",
    version="1.0.0",
)

# Allow the frontend (served separately) to call this API during development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# In-memory "database": { parcel_id: [ {"lat":..., "lng":..., "label":...}, ... ] }
# ---------------------------------------------------------------------------
parcels: Dict[str, List[dict]] = {}


class Point(BaseModel):
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)
    label: str | None = None


class GenerateRequest(BaseModel):
    center_lat: float = 13.0827
    center_lng: float = 80.2707
    count: int = 25
    spread_m: float = 300  # roughly how far points scatter, in meters


@app.get("/")
def root():
    return {"message": "Land Boundary Mapping API is running. See /docs for usage."}


@app.get("/api/parcels")
def list_parcels():
    return {
        "parcels": [
            {"parcel_id": pid, "point_count": len(pts)}
            for pid, pts in parcels.items()
        ]
    }


@app.post("/api/parcels/{parcel_id}/points")
def add_point(parcel_id: str, point: Point):
    parcels.setdefault(parcel_id, []).append(point.dict())
    return {"parcel_id": parcel_id, "total_points": len(parcels[parcel_id])}


@app.get("/api/parcels/{parcel_id}/points")
def get_points(parcel_id: str):
    if parcel_id not in parcels:
        raise HTTPException(status_code=404, detail="Parcel not found")
    return {"parcel_id": parcel_id, "points": parcels[parcel_id]}


@app.delete("/api/parcels/{parcel_id}")
def clear_parcel(parcel_id: str):
    parcels.pop(parcel_id, None)
    return {"parcel_id": parcel_id, "status": "cleared"}


@app.delete("/api/parcels/{parcel_id}/points/{point_index}")
def delete_point(parcel_id: str, point_index: int):
    """Delete a single point from a parcel by its index in the list."""
    if parcel_id not in parcels or not (0 <= point_index < len(parcels[parcel_id])):
        raise HTTPException(status_code=404, detail="Point not found")
    removed = parcels[parcel_id].pop(point_index)
    return {"parcel_id": parcel_id, "removed": removed, "total_points": len(parcels[parcel_id])}


@app.get("/api/parcels/{parcel_id}/hull")
def get_hull(parcel_id: str):
    if parcel_id not in parcels or len(parcels[parcel_id]) < 3:
        raise HTTPException(
            status_code=400,
            detail="Need at least 3 points to compute a convex hull.",
        )

    points = parcels[parcel_id]
    hull = graham_scan(points)
    area = polygon_area_sqm(hull)
    perimeter = polygon_perimeter_m(hull)

    # Return as GeoJSON Polygon (ring must close: first point repeated at end)
    coordinates = [[p["lng"], p["lat"]] for p in hull]
    coordinates.append(coordinates[0])

    return {
        "parcel_id": parcel_id,
        "geojson": {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [coordinates],
            },
            "properties": {
                "area_sqm": round(area, 2),
                "area_acres": round(area / 4046.86, 4),
                "perimeter_m": round(perimeter, 2),
                "vertex_count": len(hull),
                "input_point_count": len(points),
            },
        },
    }


@app.post("/api/parcels/{parcel_id}/generate")
def generate_demo_points(parcel_id: str, req: GenerateRequest):
    """
    Generates synthetic GPS points scattered around a center coordinate.
    Useful for demoing the algorithm without needing real survey data.
    """
    # Rough conversion: 1 degree latitude ~= 111,000 meters
    deg_spread_lat = req.spread_m / 111000
    deg_spread_lng = req.spread_m / (111000 * 0.98)  # approx cos(lat) correction

    points = []
    for _ in range(req.count):
        p = {
            "lat": req.center_lat + random.uniform(-deg_spread_lat, deg_spread_lat),
            "lng": req.center_lng + random.uniform(-deg_spread_lng, deg_spread_lng),
            "label": "synthetic",
        }
        points.append(p)

    parcels[parcel_id] = points
    return {"parcel_id": parcel_id, "generated": len(points)}


@app.post("/api/parcels/{parcel_id}/import")
async def import_points(parcel_id: str, file: UploadFile = File(...)):
    """
    Bulk-import GPS points from a CSV file into a parcel.
    Expected CSV columns: lat, lng, label (label is optional).

    Use this to load either:
      - a REAL dataset produced by data/fetch_real_data.py, or
      - a SYNTHETIC dataset produced by data/generate_synthetic.py

    Example (curl):
        curl -F "file=@real_dataset.csv" \\
             http://localhost:8000/api/parcels/my-parcel/import
    """
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only .csv files are supported.")

    raw = await file.read()
    text = raw.decode("utf-8")
    reader = csv.DictReader(io.StringIO(text))

    imported = []
    for row in reader:
        try:
            lat = float(row["lat"])
            lng = float(row["lng"])
        except (KeyError, ValueError):
            continue  # skip malformed rows
        imported.append({
            "lat": lat,
            "lng": lng,
            "label": row.get("label") or "imported",
        })

    if not imported:
        raise HTTPException(status_code=400, detail="No valid rows found. CSV needs 'lat' and 'lng' columns.")

    parcels.setdefault(parcel_id, []).extend(imported)
    return {"parcel_id": parcel_id, "imported": len(imported), "total_points": len(parcels[parcel_id])}


@app.get("/api/dashboard-summary")
def dashboard_summary():
    """Aggregate stats across every parcel, for the Dashboard tab. All numbers
    are derived directly from stored data -- nothing here is simulated."""
    total_parcels = len(parcels)
    total_points = sum(len(pts) for pts in parcels.values())
    label_counts: Dict[str, int] = {}
    parcel_areas = []

    for pid, pts in parcels.items():
        for p in pts:
            lbl = p.get("label") or "unlabeled"
            label_counts[lbl] = label_counts.get(lbl, 0) + 1
        if len(pts) >= 3:
            hull = graham_scan(pts)
            if len(hull) >= 3:
                area = polygon_area_sqm(hull)
                parcel_areas.append({"parcel_id": pid, "area_acres": round(area / 4046.86, 3)})

    total_area_acres = sum(p["area_acres"] for p in parcel_areas)
    return {
        "total_parcels": total_parcels,
        "total_points": total_points,
        "total_area_acres": round(total_area_acres, 3),
        "label_breakdown": label_counts,
        "parcel_areas": parcel_areas,
    }


@app.get("/api/conflicts")
def get_conflicts():
    """
    Detects real overlaps between every pair of parcels' computed boundaries.
    Uses Sutherland-Hodgman polygon clipping to find the EXACT overlap area
    between two convex hulls -- this is genuine computational geometry, not a
    simulated or randomized "risk score".
    """
    parcel_hulls = {}
    for pid, pts in parcels.items():
        if len(pts) >= 3:
            hull = graham_scan(pts)
            if len(hull) >= 3:
                parcel_hulls[pid] = hull

    ids = list(parcel_hulls.keys())
    conflicts = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            a, b = ids[i], ids[j]
            overlap = polygons_overlap_area_sqm(parcel_hulls[a], parcel_hulls[b])
            if overlap > 0:
                area_a = polygon_area_sqm(parcel_hulls[a])
                area_b = polygon_area_sqm(parcel_hulls[b])
                severity_pct = overlap / min(area_a, area_b) * 100
                conflicts.append({
                    "parcel_a": a,
                    "parcel_b": b,
                    "overlap_sqm": round(overlap, 2),
                    "overlap_acres": round(overlap / 4046.86, 4),
                    "severity_pct": round(severity_pct, 2),
                })

    conflicts.sort(key=lambda c: -c["severity_pct"])
    return {"parcels_checked": len(ids), "conflicts": conflicts}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)