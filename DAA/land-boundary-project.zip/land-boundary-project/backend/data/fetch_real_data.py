"""
fetch_real_data.py
-------------------
Fetches REAL land parcel / building boundary data from OpenStreetMap using
the Overpass API, and saves the boundary vertices as a CSV of GPS points
that can be bulk-imported into the Land Boundary Mapping backend.

This gives you an authentic, real-world dataset (actual building/land
footprints) instead of synthetic points -- useful for showing your project
works on genuine geographic data.

Usage:
    python fetch_real_data.py --lat 13.0827 --lng 80.2707 --radius 300 --out real_dataset.csv

    --lat, --lng   Center point to search around (default: Chennai, India)
    --radius       Search radius in meters (default: 500)
    --out          Output CSV filename (default: real_dataset.csv)
    --limit        Max number of buildings to pull points from (default: 1)
                   (Set higher to combine points from multiple nearby buildings
                    into one messy "survey-like" point cloud.)

Requires internet access. If you're behind a restrictive network/firewall,
this will fail -- in that case just use generate_synthetic.py instead.
"""

import argparse
import csv
import json
import urllib.request
import urllib.parse

OVERPASS_URL = "https://overpass-api.de/api/interpreter"


def build_query(lat, lng, radius):
    # Query for building footprints (ways with a 'building' tag) near the point.
    # 'out geom' returns the full node coordinates for each way, i.e. its outline.
    return f"""
    [out:json][timeout:25];
    (
      way["building"](around:{radius},{lat},{lng});
    );
    out geom;
    """


def fetch_buildings(lat, lng, radius):
    query = build_query(lat, lng, radius)
    data = urllib.parse.urlencode({"data": query}).encode("utf-8")
    req = urllib.request.Request(OVERPASS_URL, data=data)
    with urllib.request.urlopen(req, timeout=30) as response:
        result = json.loads(response.read().decode("utf-8"))
    return result.get("elements", [])


def extract_points(elements, limit):
    """
    Pulls the (lat, lng) vertices out of each building's geometry.
    Returns a flat list of points: [{"lat":..., "lng":..., "label":...}, ...]
    """
    points = []
    for i, el in enumerate(elements[:limit]):
        geometry = el.get("geometry", [])
        name = el.get("tags", {}).get("name", f"building_{el.get('id')}")
        for node in geometry:
            points.append({
                "lat": node["lat"],
                "lng": node["lon"],
                "label": name,
            })
    return points


def save_csv(points, out_path):
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["lat", "lng", "label"])
        writer.writeheader()
        writer.writerows(points)
    print(f"Saved {len(points)} real boundary points to {out_path}")


def main():
    parser = argparse.ArgumentParser(description="Fetch real land/building boundary data from OpenStreetMap.")
    parser.add_argument("--lat", type=float, default=13.0827, help="Center latitude (default: Chennai)")
    parser.add_argument("--lng", type=float, default=80.2707, help="Center longitude (default: Chennai)")
    parser.add_argument("--radius", type=int, default=500, help="Search radius in meters")
    parser.add_argument("--limit", type=int, default=1, help="Max number of buildings to pull")
    parser.add_argument("--out", type=str, default="real_dataset.csv", help="Output CSV file path")
    args = parser.parse_args()

    print(f"Querying Overpass API around ({args.lat}, {args.lng}), radius={args.radius}m ...")
    try:
        elements = fetch_buildings(args.lat, args.lng, args.radius)
    except Exception as e:
        print(f"ERROR: Could not reach Overpass API ({e}).")
        print("Check your internet connection, or try generate_synthetic.py instead.")
        return

    if not elements:
        print("No buildings found in that area. Try a different location or larger radius.")
        return

    points = extract_points(elements, args.limit)
    if not points:
        print("Found buildings, but couldn't extract usable geometry. Try a different area.")
        return

    save_csv(points, args.out)
    print("Tip: use the /api/parcels/{id}/import endpoint (see main.py) to load this CSV into the app.")


if __name__ == "__main__":
    main()
